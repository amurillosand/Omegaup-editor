#include <bits/stdc++.h>
using namespace std;

// No hay generador menso

int main() {
  cin.tie(0)->sync_with_stdio(0), cout.tie(0);

  Random random;

  string groupName, testCaseName;
  cin >> groupName >> testCaseName;

  int n;

  if (groupName == "easy") {
    n = random.get<int>(1, 10);
  } else {
    n = random.get<int>(1, 100);
  }

  cout << n << '\n';

  auto a = random.getArray<int>(n, 1, 1000);
  for (auto x : a)
    cout << x << " ";
  cout << '\n';

  return 0;
}