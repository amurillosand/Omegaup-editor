#include <bits/stdc++.h>
using namespace std;

int main() {
  cin.tie(0)->sync_with_stdio(0), cout.tie(0);

  int a, b;
  cin >> a >> b;
  cout << a + b << '\n';

  return 0;
}